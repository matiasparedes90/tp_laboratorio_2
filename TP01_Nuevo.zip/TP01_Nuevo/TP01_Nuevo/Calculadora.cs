﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP01_Nuevo
{
    class Calculadora
    {
        public static double operar(Numero numero1, Numero numero2, string operar) { 
            double resultado=0;
            operar = validarOperador(operar);
            if (operar == "+")
                resultado = numero1.getNumero() + numero2.getNumero();
            if (operar == "-")
                resultado = numero1.getNumero() - numero2.getNumero();
            if (operar == "*")
                resultado = numero1.getNumero() * numero2.getNumero();
            if (operar == "/")
                if (numero2.getNumero() == 0)
                {
                    resultado = 0;
                }
                else 
                {
                    resultado = numero1.getNumero() / numero2.getNumero();
                }
                    

            return resultado;
        }

        public static string validarOperador(string operador) {
            if (operador == "+" || operador == "-" || operador == "*" || operador == "/")
            {
                return operador;
            }
            else 
            {
                operador = "+";
                return operador;
            }
        }
    }
}
