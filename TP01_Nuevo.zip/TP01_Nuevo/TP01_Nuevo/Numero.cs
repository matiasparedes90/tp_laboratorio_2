﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP01_Nuevo
{
    class Numero
    {
        private double numero;

        public Numero() {
            this.numero = 0;
        }

        public Numero(string numero) {
            bool validar = false;
            validar = double.TryParse(numero,out this.numero);
        }

        public Numero(double numero) {
            this.numero = numero;
        }

        public double getNumero() {
            return this.numero;
        }

        private void setNumero(string numero) {
            this.numero = validarNumero(numero);
        }

        private double validarNumero(string numeroString)
        {
            bool validar;
            double num;
            validar = double.TryParse(numeroString, out num);
            if (validar == false)
            {
                num = 0;
                return num;
            }
            return num;
        }
    }
}
