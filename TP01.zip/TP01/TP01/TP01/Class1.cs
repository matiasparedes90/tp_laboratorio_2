﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP01
{
    class Calculadora
    {
        public static double operacion(int a, int b, string operador) {
            double resultado=0,num1=0,num2=0;

            if (operador == "+")
                resultado = a + b;
            

            if (operador == "*")
                resultado = a * b;
            

            if (operador == "-")
                resultado = a - b;


            if (operador == "/" && b != 0) {
                num1 = a;
                num2 = b;
                resultado = num1 / num2;
            }
            else if (operador == "/" && b == 0) {
                resultado = 0;
            }
                

            return resultado;
        }

        public static string validarOperador(string operador) {
            if (operador != "+" && operador != "-" && operador != "*" && operador != "/") { 
                operador = "+";
            }

            return operador;
        }

        
    }
}
