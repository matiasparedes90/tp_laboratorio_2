﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            label2.Text = " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {

            int num1, num2;
            double resultado=0;
            
            bool valida1 = false, valida2 = false;

            string operador;

            //string error = "No se puede dividir por 0", operador;
            
            Numero a = new Numero();
            Numero b = new Numero();

            valida1 = double.TryParse(textBox1.Text, out resultado);
            if (valida1 == true) {
                a = new Numero(resultado);
            }
            valida2 = double.TryParse(textBox2.Text, out resultado);
            if (valida2 == true) {
                b = new Numero(resultado);
            }
            num1 = Convert.ToInt32(a.getNumero());
            num2 = Convert.ToInt32(b.getNumero());

            operador = Calculadora.validarOperador(comboBox1.Text);

            resultado = Calculadora.operacion(num1, num2, operador);

            label2.Text = resultado.ToString();

        }
    }
}
